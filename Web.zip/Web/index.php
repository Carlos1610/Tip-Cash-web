<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
    <link href="home.css" rel="stylesheet">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel='stylesheet' href="/css/bootstrap.min.css">
    <link rel='stylesheet' href="/css/style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">  
</head>
<body>
	<nav class="navbar sticky-top navbar-expand-lg navbar-light bg-light py-4">
      <a class="navbar-brand" href="home.html" >Tip-Cash</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="container" id="navbarNav">
        <ul class="navbar-nav">
        </ul>
        <a class="btn btn-primary" style="width: 150px;" href="baixe.html" role="button">Baixe o app</a>
      </div>
    </nav>
    <div class="row" class="caixa" class="texto">
      <div class="col-sm-6" class="texto">
      	<br>
      	<img src="f1.jpeg" class="img-fluid">
      	<br>
      	<br>
      	<p class="texto2">
      		O Tip-Cash é um aplicativo desenvolvido por uma equipe de TCC do COTIL com o intuito de facilitar cobranças e o grande peso de carregar diversos meios de pagamento, os trocando apenas pelo seu dispositivo movel e sem cobranças adicionais, garantindo segurança e confiabilidade para guardar os dados informados e grande disponibilidade de serviços apenas pela inserção de um QR-Code, sendo completamente gratuito e sem grandes formulários para o preenchimento do usuário por conta de sua projeção agradável visualmente e amigavel.
      	</p>
      </div>
      <div class="col-sm-5">
        <div class="accordion" id="accordionExample">
  <div class="card">
    <div class="card-header" id="headingOne">
      <h2 class="mb-0">
        <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          Fazer login
        </button>
      </h2>
    </div>
    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
      <div class="card-body">

  <form method="post" action="login.php">
    <div class="form-group">
      <label for="exampleInputEmail1">Email</label>
      <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="emailL">
    </div>
    <div class="form-group">
      <label for="exampleInputPassword1">Senha</label>
      <input type="password" class="form-control" id="exampleInputPassword1" name="senhaL">
    </div>
    <button type="submit" class="btn btn-primary">Fazer login</button>
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-header" id="headingTwo">
        <h2 class="mb-0">
          Não tem uma conta?
          <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
            Crie uma!
          </button>
        </h2>
      </div>
      <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
    </div>
  </form> <!-- Formulário de login -->
  <div class="card-body">
  <form method="post" action="cadastro.php"> <!-- Formulário de cadastro -->
    <label>Nome completo</label>
    <br>
    <div class="input-group flex-nowrap">
    <input type="text" class="form-control" aria-describedby="addon-wrapping" placeholder="" required name="nomeC">
  </div>
  <br>
  <div class="form-group">
      <label for="exampleInputEmail1">Email</label>
    <div class="input-group">
      <div class="input-group-prepend">
        <span class="input-group-text" id="addon-wrapping">@</span>
      </div>
      <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="emailC" placeholder="email@exemplo.com" required>
    </div>
    <small id="emailHelp" class="form-text text-muted">Prometemos não compartilhar seu e-mail com ninguém.</small>
  </div>
  <div id="senhaDiferente" class="container-fluid"></div>
  <div class="form-group">
      <label for="exampleInputPassword1">Senha</label>
      <input type="password" class="form-control" id="exampleInputPassword1" id="SenhaA">
    </div>
    <div class="form-group">
      <label for="exampleInputPassword1">Confirmar Senha</label>
      <input type="password" class="form-control" id="exampleInputPassword1" name="senhaC" id="SenhaB">
    </div>
  <div class="form-group form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1" name="termos" required>
    <label class="form-check-label" for="exampleCheck1">Eu li e aceito os <a href="termos.php">termos de uso</a> e a <a href="privacidade.html">Política de Privacidade</a>.</label>
  </div>
  <div class="form-group">
  </div>
  <button type="submit" class="btn btn-primary">Cadastrar</button>
</div>
</form>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
</p>
  </div>
    </div>
      <footer id="myFooter">
        <div class="container">
          <div class="row">
            <div class="col-sm-3">
              <h2 class="logo">
                 <a href="home.html"> Tip'Cash </a>
              </h2>
             </div>
            <div class="col-sm-2">
              <h5>Inicio</h5>
              <ul>
                <li><a href="https://programadorviking.com.br/">Home</a></li>
              </ul>
            </div>
            <div class="col-sm-2">
              <h5>Sobre-nós</h5>
              <ul>
                <li>
                  <a href="https://programadorviking.com.br/">Informações da Empresa</a>
                </li>
                <li><a href="https://programadorviking.com.br/">Contato</a></li>   
                  </ul>
            </div>
            <div class="col-sm-2">
              <h5>Suporte</h5>
              <ul>
                <li><a href="https://programadorviking.com.br/">FAQ</a></li>
                <li><a href="https://programadorviking.com.br/">Telefones</a></li>
                <li><a href="https://programadorviking.com.br/">Chat</a></li>
              </ul>
            </div>
            <div class="col-sm-3">
            <div class="social-networks">
              <a href="https://programadorviking.com.br/" class="twitter"><i class="fa fa-twitter"></i></a>
              <a href="https://programadorviking.com.br/" class="facebook"><i class="fa fa-facebook"></i></a>
              <a href="https://programadorviking.com.br/" class="instagram"><i class="fa fa-instagram"></i></a>
            </div>
            <a href="https://programadorviking.com.br/">
              <button type="button" class="btn btn-default">Contato</button>
            </a>
            </div>
          </div>
        </div>
        <div class="footer-copyright">
        </div>
      </footer>
</body>
</html>