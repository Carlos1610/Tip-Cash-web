<?php
namespace chillerlan\QRCodeExamples;
use chillerlan\QRCode\{QRCode, QROptions};
include './vendor/autoload.php';
$url = 'https://celke.com.br/curso/curso-de-php';
$options = new QROptions([
	'version'    => 5,
	'outputType' => QRCode::OUTPUT_MARKUP_SVG,
	'eccLevel'   => QRCode::ECC_L,
]);
$qrcode = new QRCode($options);
$qrcode->render($url, 'imgqrcode/curso-de-php.svg');
echo "<img src='imgqrcode/curso-de-php.svg' width='200'>";
?>