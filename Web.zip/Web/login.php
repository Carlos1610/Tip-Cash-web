<?php  
	include 'conexao.php';
	session_start();
	$s = $_POST['senhaL'];
	$e = $_POST['emailL'];
	$sql = "SELECT * FROM `User` WHERE `email` = '$e' AND `senha`= '$s'";
	$result = $con->query($sql);
	if ($result->num_rows > 0) 
	{
		$_SESSION["email"] = $e;
		$_SESSION["senha"] = $s;
		header('Location: home.html');
	}
	else
	{
		header('Location: index.php');
	}
?>