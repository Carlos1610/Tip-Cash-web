<!DOCTYPE html>
<?php include("conexao.php") ?>
<html>
<head>
	<title>a</title>
</head>
<body>
	<p>texto</p>
</body>
</html>