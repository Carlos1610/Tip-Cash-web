function Validar() {
    var s1 = document.getElementById('SenhaA').value;
    var s2 = document.getElementById('SenhaB').value;
    if(s1 == s2)
    {

    }
    else
    {
    	alert('batata');
    	document.getElementById("erro").innerHTML = "<div class='error'>Senhas incompátiveis</div>";

    }
}